// Setup Page Content and Logic

let currentTab = 'basics';
let currentHelpMode = 'guidance';

function switchTab(tabId) {
    currentTab = tabId;
    
    // Update nav items
    document.querySelectorAll('.nav-item').forEach(btn => {
        btn.classList.remove('active');
    });
    document.getElementById('nav-' + tabId).classList.add('active');
    
    // Render content
    const contentArea = document.getElementById('content-area');
    contentArea.innerHTML = renderTabContent(tabId);
    contentArea.scrollTop = 0;
    
    // Update help
    updateHelp(tabId);
}

function renderTabContent(tabId) {
    switch(tabId) {
        case 'basics':
            return renderBasics();
        case 'scope':
            return renderScope();
        case 'id':
            return renderPropertyID();
        case 'inspection':
            return renderInspection();
        default:
            return '<p>Content not found</p>';
    }
}

function renderBasics() {
    return `
        <div class="max-w-5xl mx-auto space-y-6 animate-fade-in">
            <div class="card">
                <h3 class="card-header">Property Address</h3>
                ${renderField({type: 'text', label: 'Street Address', required: true, placeholder: '1478 South 30th Street West'})}
                <div class="grid grid-cols-2 gap-4">
                    ${renderField({type: 'text', label: 'City', required: true, placeholder: 'Billings'})}
                    ${renderField({type: 'text', label: 'State', required: true, placeholder: 'Montana'})}
                </div>
                <div class="grid grid-cols-2 gap-4">
                    ${renderField({type: 'text', label: 'ZIP Code', required: true, placeholder: '59102'})}
                    ${renderField({type: 'text', label: 'County', required: true, placeholder: 'Yellowstone'})}
                </div>
            </div>

            <div class="card">
                <h3 class="card-header">Key Dates</h3>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    ${renderField({type: 'date', label: 'Date of Report', required: true})}
                    ${renderField({type: 'date', label: 'Date of Inspection', required: true})}
                </div>
            </div>

            <div class="card">
                <h3 class="card-header">Property Type Selection</h3>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div class="property-type-card" onclick="selectPropertyType('Commercial')" id="type-commercial">
                        <div class="check-badge">
                            <svg fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path></svg>
                        </div>
                        <div class="type-icon">
                            <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path>
                            </svg>
                        </div>
                        <div class="type-label">Commercial</div>
                        <div class="type-description">Office, Retail, Industrial</div>
                    </div>
                    <div class="property-type-card" onclick="selectPropertyType('Residential')" id="type-residential">
                        <div class="check-badge">
                            <svg fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path></svg>
                        </div>
                        <div class="type-icon">
                            <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path>
                            </svg>
                        </div>
                        <div class="type-label">Residential</div>
                        <div class="type-description">1-4 Family, Condo</div>
                    </div>
                    <div class="property-type-card" onclick="selectPropertyType('Land')" id="type-land">
                        <div class="check-badge">
                            <svg fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path></svg>
                        </div>
                        <div class="type-icon">
                            <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                            </svg>
                        </div>
                        <div class="type-label">Land</div>
                        <div class="type-description">Vacant, Subdivided</div>
                    </div>
                </div>
            </div>

            <div class="card" id="subtype-section" style="display: none;">
                <h3 class="card-header">Property Sub-Type</h3>
                <div id="subtype-options" class="grid grid-cols-2 md:grid-cols-3 gap-4"></div>
            </div>

            <div class="card">
                <h3 class="card-header">Valuation Scenarios</h3>
                <p class="text-sm text-gray-600 mb-4">Define your valuation scenarios (e.g., As Is, As Completed) and select the applicable approaches for each.</p>
                <div id="scenarios-container">
                    ${renderScenarios()}
                </div>
            </div>
        </div>
    `;
}

function renderScope() {
    let html = `<div class="space-y-6">`;
    // Purpose & Intended Use
    html += `<div class="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">`;
    html += `<h3 class="text-lg font-semibold text-gray-900 mb-4">Purpose & Scope</h3>`;
    html += `<div class="space-y-4">`;
    html += renderField({ type: 'select', label: 'Purpose of Appraisal', options: ['Market Value', 'Insurable Value', 'Liquidation Value'] });
    html += renderField({ type: 'select', label: 'Intended Use', options: ['Financing', 'Estate Planning', 'Litigation', 'Purchase/Sale'] });
    html += renderField({ type: 'text', label: 'Intended User(s)' });
    html += renderField({ type: 'select', label: 'Property Interest', options: ['Fee Simple', 'Leased Fee', 'Leasehold'] });
    html += `</div></div>`;
    html += `</div>`;
    return html;
}

function renderPropertyID() {
    return `<div class="space-y-6">
        <div class="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Property Identification Details</h3>
            <div class="grid grid-cols-1 gap-6">
                ${renderField({ type: 'text', label: 'Property Name (e.g. Canyon Creek Apts)' })}
            </div>
            <div class="mt-4">
                ${renderField({ type: 'textarea', label: 'Legal Description', rows: 3 })}
            </div>
        </div>
        <div class="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">
            <h3 class="text-lg font-semibold text-gray-900 mb-4">Ownership & Tax</h3>
            <div class="grid grid-cols-2 gap-6">
                ${renderField({ type: 'text', label: 'Current Owner' })}
                ${renderField({ type: 'text', label: 'Tax ID / Parcel #' })}
                ${renderField({ type: 'date', label: 'Last Sale Date' })}
                ${renderField({ type: 'currency', label: 'Last Sale Price' })}
            </div>
            <div class="mt-4">
                ${renderField({ type: 'textarea', label: '3-Year Sales History', rows: 3, placeholder: 'Describe any transfers in the last 3 years...' })}
            </div>
        </div>
    </div>`;
}

function renderInspection() {
    let html = `<div class="space-y-6">`;
    html += `<div class="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">`;
    html += `<h3 class="text-lg font-semibold text-gray-900 mb-4">Subject Property Inspection</h3>`;
    html += renderField({ type: 'select', label: 'Inspection Type', id: 'inspection_type', options: ['Interior & Exterior Inspection', 'Exterior Only Inspection', 'Desktop / No Inspection'] });
    html += renderField({ type: 'date', label: 'Date of Inspection', id: 'inspection_date' });
    html += `<div class="mt-4">`;
    html += `<label class="block text-sm font-medium text-gray-700 mb-2">Did you personally inspect the property?</label>`;
    html += `<div class="flex gap-4">`;
    html += `<label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 w-full">`;
    html += `<input type="radio" name="personal_inspection" value="yes" checked class="mr-2 text-harken-accent focus:ring-harken-accent" onclick="document.getElementById('inspector_details').classList.add('hidden')">`;
    html += `<span>Yes, I inspected it personally</span>`;
    html += `</label>`;
    html += `<label class="flex items-center p-3 border rounded-lg cursor-pointer hover:bg-gray-50 w-full">`;
    html += `<input type="radio" name="personal_inspection" value="no" class="mr-2 text-harken-accent focus:ring-harken-accent" onclick="document.getElementById('inspector_details').classList.remove('hidden')">`;
    html += `<span>No, I did not inspect it</span>`;
    html += `</label>`;
    html += `</div>`;
    html += `</div>`;
    html += `<div id="inspector_details" class="hidden mt-4 p-4 bg-gray-50 rounded-lg border border-gray-200">`;
    html += `<h4 class="text-sm font-semibold text-gray-900 mb-3">Contract Appraiser / Inspector Details</h4>`;
    html += `<div class="grid grid-cols-1 md:grid-cols-2 gap-4">`;
    html += renderField({ type: 'text', label: 'Inspector Name', id: 'inspector_name' });
    html += renderField({ type: 'text', label: 'License Number', id: 'inspector_license' });
    html += `</div>`;
    html += `</div>`;
    html += `</div>`;
    html += `<div class="bg-white p-6 rounded-lg border border-gray-200 shadow-sm">`;
    html += `<h3 class="text-lg font-semibold text-gray-900 mb-4">USPAP Certification & Assistance</h3>`;
    html += `<p class="text-sm text-gray-500 mb-4">Identify any significant professional assistance provided by others.</p>`;
    html += renderField({ type: 'textarea', label: 'Significant Appraisal Assistance', id: 'inspection_assistance', rows: 3, placeholder: 'Name and description of assistance (e.g. John Doe provided market research...)' });
    html += `</div>`;
    html += `</div>`;
    return html;
}

function selectPropertyType(type) {
    // Update UI
    document.querySelectorAll('.property-type-card').forEach(card => {
        card.classList.remove('selected');
    });
    document.getElementById('type-' + type.toLowerCase()).classList.add('selected');
    
    // Save to state
    WizardState.set('propertyType', type);
    
    // Update help sidebar
    updateHelpForPropertyType(type);
    
    // Show subtype options
    showSubtypes(type);
}

function showSubtypes(type) {
    const section = document.getElementById('subtype-section');
    const optionsDiv = document.getElementById('subtype-options');
    
    const subtypeData = {
        'Commercial': [
            { id: 'office', name: 'Office', description: 'CBD, Suburban, Medical', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>' },
            { id: 'retail', name: 'Retail', description: 'Strip Center, Mall, Standalone', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z"></path></svg>' },
            { id: 'industrial', name: 'Industrial', description: 'Warehouse, Manufacturing, Flex', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z"></path></svg>' },
            { id: 'multifamily', name: 'Multi-Family (5+)', description: 'Apartment Complex, 5+ Units', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z"></path></svg>' },
            { id: 'mixeduse', name: 'Mixed-Use', description: 'Residential + Commercial', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"></path></svg>' },
            { id: 'hospitality', name: 'Hospitality', description: 'Hotel, Motel, Resort', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>' }
        ],
        'Residential': [
            { id: 'singlefamily', name: 'Single Family', description: 'Detached Residence', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>' },
            { id: 'condo', name: 'Condo', description: 'Individual Unit Ownership', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>' },
            { id: 'townhome', name: 'Townhome', description: 'Attached Residence', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 14v3m4-3v3m4-3v3M3 21h18M3 10h18M3 7l9-4 9 4M4 10h16v11H4V10z"></path></svg>' },
            { id: '2-4unit', name: '2-4 Unit', description: 'Small Multi-Family', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z"></path></svg>' }
        ],
        'Land': [
            { id: 'vacant', name: 'Vacant Land', description: 'Undeveloped Parcel', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3.055 11H5a2 2 0 012 2v1a2 2 0 002 2 2 2 0 012 2v2.945M8 3.935V5.5A2.5 2.5 0 0010.5 8h.5a2 2 0 012 2 2 2 0 104 0 2 2 0 012-2h1.064M15 20.488V18a2 2 0 012-2h3.064M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>' },
            { id: 'reslot', name: 'Residential Lot', description: 'Buildable Lot, Subdivision', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"></path></svg>' },
            { id: 'commsite', name: 'Commercial Site', description: 'Development Ready', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4"></path></svg>' },
            { id: 'agricultural', name: 'Agricultural', description: 'Farm, Ranch, Orchard', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>' },
            { id: 'subdivision', name: 'Subdivision', description: 'Multiple Lots, Platted', icon: '<svg class="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z"></path></svg>' }
        ]
    };
    
    const subtypes = subtypeData[type] || [];
    let html = '';
    
    subtypes.forEach(subtype => {
        html += `
            <div class="property-type-card" onclick="selectSubtype('${subtype.id}')" id="subtype-${subtype.id}">
                <div class="check-badge">
                    <svg fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <div class="type-icon">
                    ${subtype.icon}
                </div>
                <div class="type-label">${subtype.name}</div>
                <div class="type-description">${subtype.description}</div>
            </div>
        `;
    });
    
    optionsDiv.innerHTML = html;
    section.style.display = 'block';
    
    // Animate in
    setTimeout(() => {
        section.classList.add('animate-fade-in');
    }, 50);
}

function selectSubtype(subtypeId) {
    // Update UI
    document.querySelectorAll('[id^="subtype-"]').forEach(card => {
        card.classList.remove('selected');
    });
    document.getElementById('subtype-' + subtypeId).classList.add('selected');
    
    // Save to state
    WizardState.set('propertySubtype', subtypeId);
    
    console.log('Subtype selected:', subtypeId);
}

function switchHelpMode(mode) {
    currentHelpMode = mode;
    
    // Update header tabs
    const guidanceBtn = document.getElementById('header-tab-guidance');
    const valuesBtn = document.getElementById('header-tab-values');
    
    if (mode === 'guidance') {
        guidanceBtn.classList.add('bg-white', 'text-gray-900', 'shadow-sm');
        guidanceBtn.classList.remove('text-gray-600');
        valuesBtn.classList.remove('bg-white', 'text-gray-900', 'shadow-sm');
        valuesBtn.classList.add('text-gray-600');
    } else {
        valuesBtn.classList.add('bg-white', 'text-gray-900', 'shadow-sm');
        valuesBtn.classList.remove('text-gray-600');
        guidanceBtn.classList.remove('bg-white', 'text-gray-900', 'shadow-sm');
        guidanceBtn.classList.add('text-gray-600');
    }
    
    // Update content
    const helpContent = document.getElementById('help-content');
    if (mode === 'guidance') {
        updateHelp(currentTab);
    } else {
        renderValuesPanel();
    }
}

function toggleFullScreen() {
    const leftSidebar = document.getElementById('left-sidebar');
    const helpSidebar = document.getElementById('help-sidebar');
    
    // Toggle both sidebars
    if (leftSidebar.classList.contains('collapsed')) {
        // Expand both
        leftSidebar.classList.remove('collapsed');
        helpSidebar.classList.remove('collapsed');
    } else {
        // Collapse both
        leftSidebar.classList.add('collapsed');
        helpSidebar.classList.add('collapsed');
    }
}

function updateHelp(tabId) {
    if (currentHelpMode !== 'guidance') return;
    
    const helpContent = document.getElementById('help-content');
    const helpText = {
        'basics': `
            <h3 class="text-lg font-bold text-gray-900 mb-3">Assignment Basics</h3>
            <p class="text-sm text-gray-600 mb-4">Select the property type and sub-type. This determines which valuation approaches are most appropriate and which sections of the report will be emphasized.</p>
            <div class="bg-blue-50 border-l-4 border-blue-500 p-3 rounded">
                <h4 class="font-semibold text-sm text-blue-900 mb-1">Tip</h4>
                <p class="text-xs text-blue-800">The property type selection will automatically configure the appropriate valuation approaches and report sections.</p>
            </div>
        `,
        'scope': `
            <h3 class="text-lg font-bold text-gray-900 mb-3">Purpose & Scope</h3>
            <p class="text-sm text-gray-600 mb-4">Define the intended use, intended users, and scope of work. This is required by USPAP Standards Rule 2-2(a).</p>
            <div class="bg-amber-50 border-l-4 border-amber-500 p-3 rounded">
                <h4 class="font-semibold text-sm text-amber-900 mb-1">USPAP Requirement</h4>
                <p class="text-xs text-amber-800">Standards Rule 2-2(a) requires clear identification of the client, intended use, and intended users.</p>
            </div>
        `,
        'id': `
            <h3 class="text-lg font-bold text-gray-900 mb-3">Property Identification</h3>
            <p class="text-sm text-gray-600 mb-4">Provide complete identification of the property including address, legal description, and ownership information.</p>
            <div class="bg-green-50 border-l-4 border-green-500 p-3 rounded">
                <h4 class="font-semibold text-sm text-green-900 mb-1">Best Practice</h4>
                <p class="text-xs text-green-800">Verify the legal description matches current deed records and include all parcels if the property consists of multiple tax lots.</p>
            </div>
        `,
        'inspection': `
            <h3 class="text-lg font-bold text-gray-900 mb-3">Inspection & Teams</h3>
            <p class="text-sm text-gray-600 mb-4">Document who inspected the property and when. USPAP requires disclosure of any assistance received.</p>
            <div class="bg-purple-50 border-l-4 border-purple-500 p-3 rounded">
                <h4 class="font-semibold text-sm text-purple-900 mb-1">USPAP Disclosure</h4>
                <p class="text-xs text-purple-800">You must disclose any significant professional assistance received in the assignment.</p>
            </div>
        `
    };
    helpContent.innerHTML = helpText[tabId] || '';
}

function updateHelpForPropertyType(type) {
    if (currentHelpMode !== 'guidance') return;
    
    const helpContent = document.getElementById('help-content');
    const typeHelp = {
        'Commercial': `
            <h3 class="text-lg font-bold text-gray-900 mb-3">Commercial Property</h3>
            <div class="bg-blue-50 border-l-4 border-blue-500 p-4 rounded mb-4">
                <h4 class="font-semibold text-sm text-blue-900 mb-2">Valuation Focus</h4>
                <p class="text-xs text-blue-800 leading-relaxed">Income Approach is typically most heavily weighted for commercial properties. Analyze rent rolls, operating expenses, and market cap rates carefully.</p>
            </div>
            <div class="space-y-2">
                <h4 class="font-semibold text-sm text-gray-900">Key Considerations:</h4>
                <ul class="text-xs text-gray-600 space-y-1 list-disc list-inside">
                    <li>Tenant credit quality and lease terms</li>
                    <li>Operating expense ratios</li>
                    <li>Market rental rates and vacancy</li>
                    <li>Capitalization rate support</li>
                </ul>
            </div>
        `,
        'Residential': `
            <h3 class="text-lg font-bold text-gray-900 mb-3">Residential Property</h3>
            <div class="bg-green-50 border-l-4 border-green-500 p-4 rounded mb-4">
                <h4 class="font-semibold text-sm text-green-900 mb-2">Valuation Focus</h4>
                <p class="text-xs text-green-800 leading-relaxed">Sales Comparison Approach is primary for residential properties. Analyze recent comparable sales with careful adjustments for differences.</p>
            </div>
            <div class="space-y-2">
                <h4 class="font-semibold text-sm text-gray-900">Key Considerations:</h4>
                <ul class="text-xs text-gray-600 space-y-1 list-disc list-inside">
                    <li>Recent comparable sales (within 6-12 months)</li>
                    <li>Location and neighborhood compatibility</li>
                    <li>Size, condition, and quality adjustments</li>
                    <li>Market trends and absorption rates</li>
                </ul>
            </div>
        `,
        'Land': `
            <h3 class="text-lg font-bold text-gray-900 mb-3">Land Valuation</h3>
            <div class="bg-yellow-50 border-l-4 border-yellow-500 p-4 rounded mb-4">
                <h4 class="font-semibold text-sm text-yellow-900 mb-2">Valuation Focus</h4>
                <p class="text-xs text-yellow-800 leading-relaxed">Highest & Best Use analysis is critical for land. Sales Comparison or Allocation/Extraction methods are typical approaches.</p>
            </div>
            <div class="space-y-2">
                <h4 class="font-semibold text-sm text-gray-900">Key Considerations:</h4>
                <ul class="text-xs text-gray-600 space-y-1 list-disc list-inside">
                    <li>Zoning and permitted uses</li>
                    <li>Utilities availability and costs</li>
                    <li>Development feasibility</li>
                    <li>Comparable land sales analysis</li>
                </ul>
            </div>
        `
    };
    helpContent.innerHTML = typeHelp[type] || '';
}

function renderValuesPanel() {
    const helpContent = document.getElementById('help-content');
    helpContent.innerHTML = `
        <h3 class="text-lg font-bold text-gray-900 mb-4">Weighted Values</h3>
        <div class="bg-white border-2 border-gray-200 rounded-lg p-4 mb-4">
            <div class="text-xs text-gray-500 uppercase tracking-wide mb-2">Preliminary Conclusion</div>
            <div class="text-3xl font-bold text-harken-accent">$5,200,000</div>
        </div>
        <div class="space-y-3">
            <div class="bg-blue-50 border-l-4 border-blue-500 p-3 rounded">
                <div class="flex justify-between items-center mb-1">
                    <span class="text-sm font-semibold text-blue-900">Sales Comparison</span>
                    <span class="text-xs font-bold text-blue-700">40%</span>
                </div>
                <div class="text-lg font-bold text-gray-900">$5,130,000</div>
            </div>
            <div class="bg-green-50 border-l-4 border-green-500 p-3 rounded">
                <div class="flex justify-between items-center mb-1">
                    <span class="text-sm font-semibold text-green-900">Income Approach</span>
                    <span class="text-xs font-bold text-green-700">40%</span>
                </div>
                <div class="text-lg font-bold text-gray-900">$5,300,000</div>
            </div>
            <div class="bg-purple-50 border-l-4 border-purple-500 p-3 rounded">
                <div class="flex justify-between items-center mb-1">
                    <span class="text-sm font-semibold text-purple-900">Cost Approach</span>
                    <span class="text-xs font-bold text-purple-700">20%</span>
                </div>
                <div class="text-lg font-bold text-gray-900">$5,290,000</div>
            </div>
        </div>
        <div class="mt-4 text-xs text-gray-500 bg-gray-50 p-3 rounded">
            <strong>Note:</strong> Adjust weights in the Reconciliation section (Phase 5).
        </div>
    `;
}

// Scenario Management
let scenarios = [
    { id: 1, name: 'As Is', nameSelect: 'As Is', customName: '', approaches: ['Sales Comparison'] }
];

const scenarioOptions = [
    { label: 'As Is', value: 'As Is' },
    { label: 'As Completed', value: 'As Completed' },
    { label: 'As Stabilized', value: 'As Stabilized' },
    { label: 'As Proposed', value: 'As Proposed' },
    { label: 'Type my own', value: 'Type my own' }
];

function renderScenarios() {
    let html = '<div class="space-y-4">';
    
    scenarios.forEach((scenario, index) => {
        html += `<div class="scenario-block">`;
        
        // Scenario Name with Pill Buttons
        html += `<div class="flex justify-between items-start mb-4 gap-4">`;
        html += `<div class="flex-1">`;
        html += `<label class="block text-sm font-medium text-gray-700 mb-2">Scenario Name</label>`;
        html += `<div class="scenario-name-pills">`;
        scenarioOptions.forEach(opt => {
            const isSelected = scenario.nameSelect === opt.value;
            const pillClass = opt.value === 'Type my own' ? 'scenario-pill custom' : 'scenario-pill';
            html += `<button type="button" class="${pillClass} ${isSelected ? 'selected' : ''}" onclick="updateScenarioName(${scenario.id}, 'pill', '${opt.value}')">
                ${opt.label}
            </button>`;
        });
        html += `</div>`;
        
        // Custom input if "Type my own" is selected
        if (scenario.nameSelect === 'Type my own' || (scenario.name && !scenarioOptions.some(opt => opt.value === scenario.name))) {
            const customVal = scenario.customName || (scenario.nameSelect === 'Type my own' ? '' : scenario.name);
            html += `<div class="scenario-custom-input">
                <input type="text" class="w-full rounded-md border-gray-300 shadow-sm focus:border-harken-accent focus:ring focus:ring-harken-accent focus:ring-opacity-50 px-3 py-2" placeholder="Enter custom scenario name..." value="${customVal}" onchange="updateScenarioName(${scenario.id}, 'custom', this.value)">
            </div>`;
        }
        html += `</div>`;
        
        // Delete button (only if more than one scenario)
        if (scenarios.length > 1) {
            html += `<button onclick="removeScenario(${scenario.id})" class="text-red-500 hover:text-red-700 p-2 transition-colors rounded-full hover:bg-red-50" title="Remove Scenario">
                <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
            </button>`;
        }
        html += `</div>`;

        // Approaches Grid with Cards
        html += `<label class="block text-sm font-medium text-gray-700 mb-2">Select Approaches for this Scenario</label>`;
        html += `<div class="approach-grid">`;
        
        const approaches = [
            { key: 'Sales Comparison', label: 'Sales Comparison', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
            { key: 'Cost Approach', label: 'Cost Approach', icon: 'M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4' },
            { key: 'Income Approach', label: 'Income Approach', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' }
        ];

        approaches.forEach(app => {
            const isSelected = scenario.approaches.includes(app.key);
            html += `
            <div class="approach-card ${isSelected ? 'selected' : ''}" onclick="toggleScenarioApproach(${scenario.id}, '${app.key}')">
                <div class="check-badge">
                    <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="3" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7"></path></svg>
                </div>
                <div class="approach-icon">
                    <svg class="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="${app.icon}"></path></svg>
                </div>
                <span class="approach-label">${app.label}</span>
            </div>`;
        });
        
        html += `</div>`; // End approach grid
        html += `</div>`; // End scenario block
    });

    // Add Scenario Button
    html += `<button onclick="addScenario()" class="btn-add-scenario">
        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"></path></svg>
        Add Another Scenario
    </button>`;
    
    html += '</div>';
    return html;
}

function addScenario() {
    const newId = scenarios.length > 0 ? Math.max(...scenarios.map(s => s.id)) + 1 : 1;
    scenarios.push({ id: newId, name: '', nameSelect: '', customName: '', approaches: [] });
    
    // Only re-render the scenarios section
    updateScenariosDisplay();
}

function removeScenario(id) {
    scenarios = scenarios.filter(s => s.id !== id);
    
    // Only re-render the scenarios section
    updateScenariosDisplay();
}

function updateScenarioName(id, type, value) {
    const scenario = scenarios.find(s => s.id === id);
    if (!scenario) return;

    if (type === 'pill') {
        if (value === 'Type my own') {
            scenario.nameSelect = 'Type my own';
            scenario.name = scenario.customName || '';
        } else {
            scenario.nameSelect = value;
            scenario.name = value;
            scenario.customName = '';
        }
        // Re-render to show/hide custom input
        updateScenariosDisplay();
    } else if (type === 'custom') {
        // For custom input, just update the value without re-rendering
        scenario.customName = value;
        scenario.name = value;
    }
}

function toggleScenarioApproach(id, approach) {
    // Find the card element for immediate visual feedback
    const cards = document.querySelectorAll('.approach-card');
    let clickedCard = null;
    cards.forEach(card => {
        const cardText = card.querySelector('.approach-label')?.textContent;
        const cardScenario = card.closest('.scenario-block');
        if (cardText === approach && cardScenario) {
            // Check if this card belongs to the right scenario by checking its position
            const allScenarioBlocks = document.querySelectorAll('.scenario-block');
            const scenarioIndex = Array.from(allScenarioBlocks).indexOf(cardScenario);
            if (scenarios[scenarioIndex]?.id === id) {
                clickedCard = card;
            }
        }
    });
    
    // Immediate visual feedback - toggle the selected class
    if (clickedCard) {
        clickedCard.classList.toggle('selected');
    }
    
    // Update data in background
    const scenario = scenarios.find(s => s.id === id);
    if (!scenario) return;

    const index = scenario.approaches.indexOf(approach);
    if (index === -1) {
        scenario.approaches.push(approach);
    } else {
        scenario.approaches.splice(index, 1);
    }
    
    // Update global approaches for backward compatibility
    const allApproaches = new Set();
    scenarios.forEach(s => {
        s.approaches.forEach(a => allApproaches.add(a));
    });
    
    const approachMap = {
        'Sales Comparison': 'sales',
        'Cost Approach': 'cost',
        'Income Approach': 'income'
    };

    Object.keys(approachMap).forEach(key => {
        const globalKey = approachMap[key];
        if (assignmentContext.approaches[globalKey]) {
            assignmentContext.approaches[globalKey].enabled = allApproaches.has(key);
        }
    });
}

// Helper function to update only the scenarios display
function updateScenariosDisplay() {
    const scenariosContainer = document.getElementById('scenarios-container');
    if (scenariosContainer) {
        scenariosContainer.innerHTML = renderScenarios();
    }
}

// Initialize
window.addEventListener('DOMContentLoaded', function() {
    switchTab('basics');
});

