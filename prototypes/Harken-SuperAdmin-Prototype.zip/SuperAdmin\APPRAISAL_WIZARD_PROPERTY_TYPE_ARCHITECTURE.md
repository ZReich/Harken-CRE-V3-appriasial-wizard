# Appraisal Wizard Property-Type Architecture

This document extends the current `appraisal-wizard-prototype.html` to support property-type branching, configurable valuation approaches, and a pre-PDF review experience aligned with the Evaluation Wizard.

---

## 1. Workflow Mapping

### 1.1 Entry Flow
1. **Engagement Setup**
   - User selects *Commercial*, *Residential*, or *Land* immediately after project creation (mirrors Evaluation Wizard landing screen).
   - Each choice stores `propertyType` on the project record and hydrates downstream UI.
2. **Sub-Type Selection**
   - Commercial: Industrial, Office, Retail, Medical, Mixed-Use, Specialized.
   - Residential: Single-Family, Multi-Family (2–4), Multi-Family (5+), Condo, Manufactured Housing.
   - Land: Finished Lot, Entitled Land, Agricultural, Transitional, Special Use.
   - Sub-type drives default sections, comps templates, and critical fields.
3. **Wizard Navigation**
   - Left navigation retains master list of 21 sections but highlights context-specific screens (e.g., Land shows Soil/Entitlements cards earlier, Residential shows Unit Mix grids only when Multi-Family).

### 1.2 Subcategory Impact
| Property Type | Key Differences | Screens Emphasized |
|---------------|-----------------|--------------------|
| Commercial – Industrial | Loading docks, clear height, flex unit mix | Improvements, Sales/Lease comps filters |
| Commercial – Office/Retail | Tenant mix, TI allowances, foot traffic metrics | Income Approach → Lease comps, Market Analysis |
| Residential – Single Family | Comparable sales weights, neighborhood amenities | Sales Comparison grid, Neighborhood/Site detail |
| Residential – Multi-Family | Unit mix, GRM, rent roll import | Income Approach (GRM), Operating Expenses |
| Land – Finished/Entitled | Entitlement milestones, absorption | Site Analysis, Cost Approach Land valuation |
| Land – Agricultural/Transitional | Soil class, water rights | Site Conditions, Market Analysis |

Each subtype toggles contextual help, default form values, and required fields. All screens remain accessible; non-applicable sections collapse with “Not required for this property” callouts to preserve USPAP coverage.

---

## 2. Approach Configuration Layer

### 2.1 Rules Matrix (Cost, Sales, Income always available)

| Property Segment | Default Enabled Approaches | Conditional Logic |
|------------------|---------------------------|-------------------|
| Commercial (all sub-types) | Cost, Sales, Income | Income auto-focus for stabilized assets; Cost emphasized for proposed construction. |
| Residential – Single Family | Sales, Cost | Income toggle exposed; when `hasRentalIntent=true`, Income becomes required. |
| Residential – Multi-Family | Sales, Income, Cost | GRM auto-enabled; Cost optional depending on construction status. |
| Land (all sub-types) | Sales, Cost | Income option remains visible for ground leases or agricultural income modeling. |

### 2.2 UI Controls
- **Approach Selector Panel** (new card above “Valuation Approaches” section)
  - Checkboxes for Cost, Sales, Income.
  - Microcopy reminding users all three are available regardless of property type.
  - Pre-checked options follow the table above; users can toggle additional approaches anytime.
- **Per-Approach Badges** inside Section 13/14/15 navigation entries to show enabled state.
- Validation ensures at least one approach is active before final review.

### 2.3 Data Representation
```ts
type ApproachConfig = {
  cost: { enabled: boolean; required: boolean };
  sales: { enabled: boolean; required: boolean };
  income: { enabled: boolean; required: boolean; mode?: 'DirectCap' | 'DCF' | 'GRM' };
};

interface AssignmentContext {
  propertyType: 'commercial' | 'residential' | 'land';
  subType: string;
  intents: { rental: boolean; development: boolean; disposition: boolean };
  approaches: ApproachConfig;
}
```
This structure can live beside the existing `wizardSteps` map to determine which sections render and what calculators to expose.

---

## 3. Dynamic Section Loading

### 3.1 Metadata Schema
Augment each `wizardSteps` entry (see `prototypes/SuperAdmin/appraisal-wizard-prototype.html`) with:
```js
const wizardSteps = {
  '13.2': {
    title: 'Improvement Valuation',
    section: 'Cost Approach',
    visibility: {
      propertyTypes: ['commercial', 'residential'],
      subTypes: ['industrial', 'office', 'retail', 'multiFamily'],
      approaches: ['cost']
    },
    fields: [/* existing definitions */]
  },
  // ...
};
```
- `propertyTypes`: restricts rendering; omit to show globally.
- `subTypes`: optional white-list for niche screens (e.g., Agricultural soil analysis).
- `approaches`: ensures sections appear when the associated approach is active.

### 3.2 Shared Components vs Overrides
- **Shared**: Report Header, Market Analysis, Neighborhood, Review screens remain identical.
- **Overrides**:
  - Improvements grids: industrial vs. retail field sets.
  - Income approach cards: GRM tables for Multi-Family, Crop yield calculator for Agricultural land.
  - Cost approach depreciation: extra defaults for proposed vs. existing improvements.

### 3.3 Loading Flow
1. Assignment context (property type, sub-type, approach config) stored in wizard state.
2. Navigation builder filters `wizardSteps` based on visibility metadata.
3. Hidden sections are still available under “Show all sections” for USPAP completeness.

---

## 4. Pre-PDF Review Experience

### 4.1 Review Stage Structure
Modeled after `EVALUATION_REPORT_EDITOR_GUIDE.md`:
1. **Summary Dashboard**
   - Cards for each approach showing status (Complete/In Progress/Missing).
   - Property snapshot (type, sub-type, key metrics).
2. **Inline Editing**
   - Clicking a summary card opens side-by-side view: left summary, right editable fields.
   - Supports quick fixes without traversing full wizard.
3. **Validation + Exceptions**
   - USPAP checklist (effective dates, certifications, limiting conditions).
   - Property-type-specific validations (e.g., Multi-Family requires unit mix totals = building area).

### 4.2 PDF Preview Workflow
1. **Generate Draft PDF** button runs same pipeline as Evaluation Wizard but flags document as *Draft*.
2. **Document Viewer** (existing evaluation viewer component) loads PDF in modal with annotation toggle.
3. **Approve & Publish**
   - Once reviewed, user clicks “Finalize Appraisal Report,” locking inputs.
   - System stores version metadata + re-generates clean PDF for delivery.

---

## 5. Integration Notes

| Area | Notes |
|------|-------|
| Frontend Prototype | Extend `prototypes/SuperAdmin/appraisal-wizard-prototype.html` to include property-type selector, approach panel, and metadata-driven navigation. |
| Future React/Vue Implementation | Mirror metadata schema in `packages/frontend/src/modules/appraisalWizard`. Use context/state machines (XState or Redux) to manage `AssignmentContext`. |
| Backend / API | Update assignment model to persist `propertyType`, `subType`, and `approachConfig`. Ensure report generation endpoint accepts these flags to pick templates. |
| Data Schema | Add lookup tables for property sub-types, approach defaults, and section visibility flags. Tie into existing `PROPERTY_TYPE_NAVIGATION_IMPLEMENTATION.md` for consistency. |
| PDF Pipeline | Reuse Evaluation report editor infrastructure (`EVALUATION_REPORT_EDITOR_IMPLEMENTATION.md`, `DYNAMIC_REPORT_EDITOR_IMPLEMENTATION.md`). Ensure Merge Fields support new land/ag data points. |

**Next Steps:**  
- Prototype the property-type selector + approach panel in the HTML mock.  
- Implement metadata filtering for navigation and form rendering.  
- Build the review/editor UI leveraging the evaluation wizard components.  
- Wire draft/final PDF endpoints once state management is finalized.

