import React from 'react';
import { Property } from '../types';
import { MapPin, Activity } from 'lucide-react';

interface PropertyCardProps {
  property: Property;
  isSubject?: boolean;
}

export const PropertyCard: React.FC<PropertyCardProps> = ({ property, isSubject }) => {
  return (
    <div className={`flex flex-col h-full ${isSubject ? 'bg-blue-50' : 'bg-white'}`}>
      <div className="relative h-32 w-full overflow-hidden group">
        <img 
          src={property.image} 
          alt={property.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110" 
        />
        {isSubject && (
          <div className="absolute top-2 left-2 bg-blue-600 text-white text-xs font-bold px-2 py-1 rounded shadow-sm">
            SUBJECT
          </div>
        )}
        {!isSubject && property.status && (
          <div className="absolute top-2 right-2 bg-slate-900/70 backdrop-blur-sm text-white text-xs font-medium px-2 py-1 rounded shadow-sm">
            {property.status}
          </div>
        )}
      </div>
      
      <div className="p-3 flex-1 flex flex-col gap-2 border-b border-r border-slate-200">
        <h3 className="font-bold text-slate-800 text-sm leading-tight line-clamp-2" title={property.name}>
          {property.name}
        </h3>
        
        <div className="flex items-start gap-1.5 text-xs text-slate-500 mt-1">
          <MapPin className="w-3.5 h-3.5 flex-shrink-0 mt-0.5 text-blue-500" />
          <span className="line-clamp-2 leading-tight">{property.address}</span>
        </div>

        {!isSubject && property.distance && (
          <div className="flex items-center gap-1.5 text-xs text-slate-400 mt-auto pt-2">
            <Activity className="w-3.5 h-3.5 text-emerald-500" />
            <span>{property.distance} away</span>
          </div>
        )}
      </div>
    </div>
  );
};