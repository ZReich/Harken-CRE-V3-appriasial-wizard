

import { Property, GridRowData, PropertyValues, Section } from './types';

export const PROPERTIES: Property[] = [
  {
    id: 'subject',
    type: 'subject',
    name: "The Loft/Wild Willy's",
    address: "1123 1st Avenue North, Billings",
    image: "https://picsum.photos/id/122/400/300", 
    status: "Subject"
  },
  {
    id: 'comp1',
    type: 'comp',
    name: "Tippy Cow Café",
    address: "279 Airport Road, Billings",
    image: "https://picsum.photos/id/437/400/300", 
    distance: "2.4 mi",
    status: "Sold 08-2024"
  },
  {
    id: 'comp2',
    type: 'comp',
    name: "Doc & Eddy's",
    address: "927 S. 32nd Street, Billings",
    image: "https://picsum.photos/id/225/400/300",
    distance: "3.1 mi",
    status: "Sold 01-2024"
  },
  {
    id: 'comp3',
    type: 'comp',
    name: "Casino Mardi Gras",
    address: "4100 King Avenue West, Billings",
    image: "https://picsum.photos/id/158/400/300",
    distance: "5.0 mi",
    status: "Sold 06-2023"
  },
  {
    id: 'comp4',
    type: 'comp',
    name: "Beartooth Bar & Grill",
    address: "305 South 1st Avenue, Laurel",
    image: "https://picsum.photos/id/431/400/300",
    distance: "12.5 mi",
    status: "Sold 12-2020"
  },
  {
    id: 'comp5',
    type: 'comp',
    name: "Dos Machos Restaurant",
    address: "980 S. 24th Street West, Billings",
    image: "https://picsum.photos/id/348/400/300",
    distance: "4.2 mi",
    status: "Sold 02-2020"
  },
  {
    id: 'comp6',
    type: 'comp',
    name: "The Red Door Lounge",
    address: "3875 Grand Avenue, Billings",
    image: "https://picsum.photos/id/435/400/300",
    distance: "6.1 mi",
    status: "Sold 11-2019"
  },
  {
    id: 'comp7',
    type: 'comp',
    name: "Jake's Downtown",
    address: "2701 1st Avenue North, Billings",
    image: "https://picsum.photos/id/238/400/300",
    distance: "0.5 mi",
    status: "Sold 09-2019"
  },
  {
    id: 'comp8',
    type: 'comp',
    name: "Bullwhackers",
    address: "1500 N 7th Ave, Bozeman",
    image: "https://picsum.photos/id/299/400/300",
    distance: "142 mi",
    status: "Sold 05-2019"
  }
];

export const INITIAL_ROWS: GridRowData[] = [
  // SECTION 1: Transaction Data (Facts)
  { id: 't1', category: 'transaction', label: 'Date of Sale', key: 'date', format: 'date', mode: 'both' },
  { id: 't2', category: 'transaction', label: 'Identification', key: 'identification', format: 'text', mode: 'both' },
  { id: 't3', category: 'transaction', label: 'Address', key: 'address_row', format: 'text', mode: 'both' },
  { id: 't4', category: 'transaction', label: 'H & B Use', key: 'hb_use_fact', format: 'text', mode: 'both' },
  { id: 't5', category: 'transaction', label: 'Year Built', key: 'year_built', format: 'text', mode: 'both' },
  { id: 't6', category: 'transaction', label: 'Effective Age', key: 'eff_age_fact', format: 'text', mode: 'both' },
  { id: 't7', category: 'transaction', label: 'Site Area SF', key: 'site_area_fact', format: 'number', mode: 'both' },
  { id: 't8', category: 'transaction', label: 'Bldg. Size', key: 'bldg_size_fact', format: 'number', mode: 'both' },
  { id: 't9', category: 'transaction', label: 'Qual./Cond.', key: 'condition_fact', format: 'text', mode: 'both' },
  
  // PRICING BLOCK
  { id: 't10', category: 'transaction', label: 'Sales Price', key: 'price', format: 'currency', mode: 'both' },
  
  // STANDARD MODE ROWS
  { id: 't11', category: 'transaction', label: 'Overall $/SF', key: 'price_sf', format: 'currency', mode: 'standard' },
  
  // RESIDUAL MODE ROWS (Backing out land)
  { id: 't10_land', category: 'transaction', label: 'Less: Land Value', key: 'land_value', format: 'currency', mode: 'residual' },
  { id: 't10_land_src', category: 'transaction', label: 'Land Val. Source', key: 'land_source', format: 'text', mode: 'residual' },
  { id: 't10_res', category: 'transaction', label: 'Residual to Imprv.', key: 'residual_value', format: 'currency', mode: 'residual', isCalculated: true },
  { id: 't10_res_sf', category: 'transaction', label: 'Residual $/SF', key: 'residual_price_sf', format: 'currency', mode: 'residual', isCalculated: true },

  { id: 't12', category: 'transaction', label: 'CAP Rate', key: 'cap_rate', format: 'percent', mode: 'both' },

  // SECTION 2: Transactional Adjustments
  { id: 'a1', category: 'adjustments', label: 'Prop. Rights', key: 'rights', format: 'text_with_adjustment', mode: 'both' },
  { id: 'a2', category: 'adjustments', label: 'Financing', key: 'financing', format: 'text_with_adjustment', mode: 'both' },
  { id: 'a3', category: 'adjustments', label: 'Cond. Sale', key: 'cond_sale', format: 'text_with_adjustment', mode: 'both' },
  { id: 'a4', category: 'adjustments', label: 'Expenditures', key: 'expenditures', format: 'text_with_adjustment', mode: 'both' },
  { id: 'a6', category: 'adjustments', label: 'Adjustment', key: 'adjustment', format: 'text', mode: 'both' },
  
  // Dynamically shown based on mode (Total Price/SF vs Residual Price/SF)
  { id: 'a7', category: 'adjustments', label: 'Adj. Price/SF', key: 'adj_price_sf', format: 'currency', mode: 'both', isCalculated: true },

  // SECTION 3: Quantitative Adjustments (New Section)
  { id: 'q1', category: 'quantitative', label: 'Time (Market Cond.)', key: 'time_adj', format: 'percent_adjustment', mode: 'both' },
  { id: 'q2', category: 'quantitative', label: 'Location', key: 'location_adj', format: 'percent_adjustment', mode: 'both' },
  { id: 'q3', category: 'quantitative', label: 'Condition', key: 'condition_adj', format: 'percent_adjustment', mode: 'both' },
  { id: 'q4', category: 'quantitative', label: 'Construction', key: 'construction_adj', format: 'percent_adjustment', mode: 'both' },
  { id: 'q5', category: 'quantitative', label: 'Economies of Scale', key: 'scale_adj', format: 'percent_adjustment', mode: 'both' },
  { id: 'q6', category: 'quantitative', label: 'Type/Use', key: 'use_adj', format: 'percent_adjustment', mode: 'both' },

  // SECTION 4: Qualitative Characteristics (Comparison)
  { id: 'p2', category: 'qualitative', label: 'H & B Use', key: 'hb_use_comp', format: 'text', mode: 'both' },
  { id: 'p3', category: 'qualitative', label: 'Effective Age', key: 'eff_age_comp', format: 'text', mode: 'both' },
  { id: 'p4', category: 'qualitative', label: 'Site Size/SF', key: 'site_area_comp', format: 'text', mode: 'both' },
  { id: 'p5', category: 'qualitative', label: 'Bldg. Size/SF', key: 'bldg_size_comp', format: 'text', mode: 'both' },
  { id: 'p7', category: 'qualitative', label: 'Site Utility', key: 'site_utility_comp', format: 'text', mode: 'both' },
  
  // SECTION 5: Valuation Analysis
  { id: 'v1', category: 'valuation', label: 'Notes', key: 'notes', format: 'text', mode: 'both' },
  
  // Changed to calculated to support auto-ranking
  { id: 'v2', category: 'valuation', label: 'Overall Comparability', key: 'overall_comp', format: 'text', mode: 'both', isCalculated: true },
  
  { id: 'v3', category: 'valuation', label: 'Overall Adjustment', key: 'overall_adj', format: 'percent', mode: 'both', isCalculated: true },
  { id: 'v4', category: 'valuation', label: 'Adjusted Price Per SF', key: 'adj_price_sf_val', format: 'currency', mode: 'both', isCalculated: true },
  
  // Weighting Row is now used for Selection OR Weighting depending on mode
  { id: 'v5', category: 'valuation', label: 'Weighting / Selection', key: 'weighting', format: 'percent', mode: 'both' },
  
  // Add Back Land for Subject (Only in Residual Mode)
  { id: 'v_add_land', category: 'valuation', label: 'Plus: Subject Land', key: 'subject_land_add_back', format: 'currency', mode: 'residual' },

  { id: 'v6', category: 'valuation', label: 'Sales Value $/SF', key: 'sales_value_sf', format: 'currency_sf', mode: 'both', isCalculated: true },
  { id: 'v7', category: 'valuation', label: 'TOTAL SALES VALUE', key: 'total_value', format: 'currency', mode: 'both', isCalculated: true },
];

export const MOCK_VALUES: PropertyValues = {
  subject: {
    // Transaction Facts
    date: { value: 'Current' },
    identification: { value: "The Loft/Wild Willy's" },
    address_row: { value: "1123 1st Avenue North" },
    hb_use_fact: { value: 'Bar/Casino/Rest' },
    year_built: { value: '1930/R2006' },
    eff_age_fact: { value: '12 yrs' },
    site_area_fact: { value: 62375 },
    bldg_size_fact: { value: 8766 },
    condition_fact: { value: 'Aver./Aver.+' },
    price: { value: null },
    price_sf: { value: null },
    cap_rate: { value: null },
    
    // Residual Data (Input for subject land add back)
    land_value: { value: 250000 }, 
    land_source: { value: 'Land Schedule' },
    subject_land_add_back: { value: 250000 },
    residual_value: { value: null },
    residual_price_sf: { value: null },

    // Adjustments
    rights: { value: 'Fee Simple', adjustment: 0 },
    financing: { value: 'Cash to Seller', adjustment: 0 },
    cond_sale: { value: 'Typical', adjustment: 0 },
    expenditures: { value: 'None', adjustment: 0 },
    adjustment: { value: '-' },
    adj_price_sf: { value: null },

    // Quantitative
    time_adj: { value: 0 },
    location_adj: { value: 0 },
    condition_adj: { value: 0 },
    construction_adj: { value: 0 },
    scale_adj: { value: 0 },
    use_adj: { value: 0 },

    // Qualitative
    hb_use_comp: { value: 'Bar/Casino/Rest' },
    eff_age_comp: { value: '12 yrs' },
    site_area_comp: { value: 62375 },
    bldg_size_comp: { value: 8766 },
    site_utility_comp: { value: 'Good' },
    
    // Valuation
    notes: { value: 'Click to Enter Property Notes' },
    overall_comp: { value: null },
    overall_adj: { value: null },
    adj_price_sf_val: { value: null },
    weighting: { value: 1.0 }, // 100%
    sales_value_sf: { value: 235.31 },
    total_value: { value: 'N/A' }
  },
  comp1: {
    date: { value: '08-2024' },
    identification: { value: "Tippy Cow Café" },
    address_row: { value: "279 Airport Road" },
    hb_use_fact: { value: 'Restaurant' },
    year_built: { value: '1977/R2000' },
    eff_age_fact: { value: '10 yrs' },
    site_area_fact: { value: 37592 },
    bldg_size_fact: { value: 3280 },
    condition_fact: { value: 'Aver./Aver.+' },
    price: { value: 1155000 },
    price_sf: { value: 352.13 },
    cap_rate: { value: 0.0624 },
    
    // Residual
    land_value: { value: 300000 }, // ~8/sf land
    land_source: { value: 'Sale 23-401' },
    subject_land_add_back: { value: null },

    rights: { value: 'Fee Simple', adjustment: 0 },
    financing: { value: '-', adjustment: 0 },
    cond_sale: { value: '-', adjustment: 0 },
    expenditures: { value: '-', adjustment: 0 },
    adjustment: { value: '-' },
    adj_price_sf: { value: 352.13 },

    // Quantitative
    time_adj: { value: 0 },
    location_adj: { value: -0.05 },
    condition_adj: { value: 0 },
    construction_adj: { value: 0 },
    scale_adj: { value: 0 },
    use_adj: { value: 0 },

    // Qualitative
    hb_use_comp: { value: '-', flag: 'similar' },
    eff_age_comp: { value: '-', flag: 'similar' },
    site_area_comp: { value: 'Inferior', flag: 'inferior' },
    bldg_size_comp: { value: 'Superior', flag: 'superior' },
    site_utility_comp: { value: 'Similar', flag: 'similar' },
    
    // Valuation
    notes: { value: 'Click to add adjustment notes' },
    overall_comp: { value: 'Superior', flag: 'superior' },
    overall_adj: { value: 0 },
    adj_price_sf_val: { value: 344.38 },
    weighting: { value: 0.25 },
    sales_value_sf: { value: null },
    total_value: { value: null }
  },
  comp2: {
    date: { value: '01-2024' },
    identification: { value: "Doc & Eddy's" },
    address_row: { value: "927 S. 32nd Street" },
    hb_use_fact: { value: 'Rest/Bar/Casino' },
    year_built: { value: '2005' },
    eff_age_fact: { value: '7 yrs' },
    site_area_fact: { value: 84684 },
    bldg_size_fact: { value: 9120 },
    condition_fact: { value: 'Aver./Aver.+' },
    price: { value: 1415000 },
    price_sf: { value: 155.15 },
    cap_rate: { value: 0.0661 },

    // Residual
    land_value: { value: 500000 },
    land_source: { value: 'Assessed Value' },
    subject_land_add_back: { value: null },

    rights: { value: 'Fee Simple', adjustment: 0 },
    financing: { value: '-', adjustment: 0 },
    cond_sale: { value: '-', adjustment: 0 },
    expenditures: { value: '-', adjustment: 0 },
    adjustment: { value: '-' },
    adj_price_sf: { value: 155.15 },

    // Quantitative
    time_adj: { value: 0.025 },
    location_adj: { value: -0.10 },
    condition_adj: { value: 0 },
    construction_adj: { value: 0.05 },
    scale_adj: { value: 0 },
    use_adj: { value: 0 },

    // Qualitative
    hb_use_comp: { value: 'Superior', flag: 'superior' },
    eff_age_comp: { value: 'Superior', flag: 'superior' },
    site_area_comp: { value: 'Superior', flag: 'superior' },
    bldg_size_comp: { value: '-', flag: 'similar' },
    site_utility_comp: { value: 'Similar', flag: 'similar' },
    
    // Valuation
    notes: { value: 'Click to add adjustment notes' },
    overall_comp: { value: 'Superior', flag: 'superior' },
    overall_adj: { value: 0 },
    adj_price_sf_val: { value: 30.45 },
    weighting: { value: 0.25 },
    sales_value_sf: { value: null },
    total_value: { value: null }
  },
  comp3: {
    date: { value: '06-2023' },
    identification: { value: "Casino Mardi Gras" },
    address_row: { value: "4100 King Avenue" },
    hb_use_fact: { value: 'Bar/Casino' },
    year_built: { value: '2007' },
    eff_age_fact: { value: '7 yrs' },
    site_area_fact: { value: 36271 },
    bldg_size_fact: { value: 4284 },
    condition_fact: { value: 'Good/Good' },
    price: { value: 1300000 },
    price_sf: { value: 303.45 },
    cap_rate: { value: 0.0564 },

    // Residual
    land_value: { value: 200000 },
    land_source: { value: 'Land Schedule' },
    subject_land_add_back: { value: null },

    rights: { value: 'Fee Simple', adjustment: 0 },
    financing: { value: '-', adjustment: 0 },
    cond_sale: { value: '-', adjustment: 0 },
    expenditures: { value: '-', adjustment: 0 },
    adjustment: { value: '-' },
    adj_price_sf: { value: 303.45 },

    // Quantitative
    time_adj: { value: 0.05 },
    location_adj: { value: -0.05 },
    condition_adj: { value: -0.05 },
    construction_adj: { value: 0 },
    scale_adj: { value: 0 },
    use_adj: { value: 0 },

    // Qualitative
    hb_use_comp: { value: 'Inferior', flag: 'inferior' },
    eff_age_comp: { value: 'Superior', flag: 'superior' },
    site_area_comp: { value: 'Inferior', flag: 'inferior' },
    bldg_size_comp: { value: 'Superior', flag: 'superior' },
    site_utility_comp: { value: 'Similar', flag: 'similar' },
    
    // Valuation
    notes: { value: 'Click to add adjustment notes' },
    overall_comp: { value: 'Superior', flag: 'superior' },
    overall_adj: { value: 0 },
    adj_price_sf_val: { value: 139.29 },
    weighting: { value: 0.25 },
    sales_value_sf: { value: null },
    total_value: { value: null }
  },
  comp4: {
    date: { value: '12-2020' },
    identification: { value: "Beartooth Bar" },
    address_row: { value: "305 South 1st" },
    hb_use_fact: { value: 'Bar/Casino/Rest' },
    year_built: { value: '1998/R2014' },
    eff_age_fact: { value: '7 yrs' },
    site_area_fact: { value: 15000 },
    bldg_size_fact: { value: 3996 },
    condition_fact: { value: 'Aver./Aver.+' },
    price: { value: 525000 },
    price_sf: { value: 131.38 },
    cap_rate: { value: 0.0739 },

    // Residual
    land_value: { value: 100000 },
    land_source: { value: 'Assessor' },
    subject_land_add_back: { value: null },

    rights: { value: 'Fee Simple', adjustment: 0 },
    financing: { value: '-', adjustment: 0 },
    cond_sale: { value: '-', adjustment: 0 },
    expenditures: { value: '-', adjustment: 0 },
    adjustment: { value: '5.0%' },
    adj_price_sf: { value: 137.95 },

    // Quantitative
    time_adj: { value: 0.15 },
    location_adj: { value: 0.10 },
    condition_adj: { value: 0 },
    construction_adj: { value: 0 },
    scale_adj: { value: 0 },
    use_adj: { value: 0 },

    // Qualitative
    hb_use_comp: { value: '-', flag: 'similar' },
    eff_age_comp: { value: 'Superior', flag: 'superior' },
    site_area_comp: { value: 'Inferior', flag: 'inferior' },
    bldg_size_comp: { value: 'Superior', flag: 'superior' },
    site_utility_comp: { value: 'Similar', flag: 'similar' },
    
    // Valuation
    notes: { value: 'Click to add adjustment notes' },
    overall_comp: { value: 'Similar', flag: 'similar' },
    overall_adj: { value: 0 },
    adj_price_sf_val: { value: 427.13 },
    weighting: { value: 0.25 },
    sales_value_sf: { value: null },
    total_value: { value: null }
  },
  comp5: {
    date: { value: '02-2020' },
    identification: { value: "Dos Machos" },
    address_row: { value: "980 S. 24th Street" },
    hb_use_fact: { value: 'Bar/Casino/Rest' },
    year_built: { value: '2000' },
    eff_age_fact: { value: '15 yrs' },
    site_area_fact: { value: 74339 },
    bldg_size_fact: { value: 8349 },
    condition_fact: { value: 'Aver./Aver.' },
    price: { value: 1850000 },
    price_sf: { value: 221.58 },
    cap_rate: { value: 0.0598 },

    // Residual
    land_value: { value: 450000 },
    land_source: { value: 'Sale 20-331' },
    subject_land_add_back: { value: null },

    rights: { value: 'Fee Simple', adjustment: 0 },
    financing: { value: '-', adjustment: 0 },
    cond_sale: { value: '-', adjustment: 0 },
    expenditures: { value: '-', adjustment: 0 },
    adjustment: { value: '10.0%' },
    adj_price_sf: { value: 243.74 },

    // Quantitative
    time_adj: { value: 0.15 },
    location_adj: { value: -0.05 },
    condition_adj: { value: 0.05 },
    construction_adj: { value: 0 },
    scale_adj: { value: 0 },
    use_adj: { value: 0 },

    // Qualitative
    hb_use_comp: { value: '-', flag: 'similar' },
    eff_age_comp: { value: '-', flag: 'similar' },
    site_area_comp: { value: 'Superior', flag: 'superior' },
    bldg_size_comp: { value: '-', flag: 'similar' },
    site_utility_comp: { value: 'Similar', flag: 'similar' },
    
    // Valuation
    notes: { value: 'Click to add adjustment notes' },
    overall_comp: { value: 'Superior', flag: 'superior' },
    overall_adj: { value: 0 },
    adj_price_sf_val: { value: 250.00 },
    weighting: { value: 0.25 },
    sales_value_sf: { value: null },
    total_value: { value: null }
  }
};

export const AVAILABLE_ELEMENTS = [
  // General / Office / Retail
  { label: 'City/State', key: 'city_state' },
  { label: 'Data Source', key: 'data_source' },
  { label: 'Year Built/Ren', key: 'year_built_ren' },
  { label: '% Office', key: 'pct_office' },
  { label: 'Sidewall Height', key: 'sidewall_height' },
  { label: 'Clear Height', key: 'clear_height' },
  { label: 'Zoning', key: 'zoning' },
  { label: 'Utilities', key: 'utilities' },
  { label: 'Topography', key: 'topography' },
  { label: 'Land Value', key: 'land_value' },
  { label: 'Bldg Value', key: 'bldg_value' },
  { label: 'Grantor', key: 'grantor' },
  { label: 'Grantee', key: 'grantee' },
  { label: 'Site Utility', key: 'site_utility' },
  
  // Industrial
  { label: 'Dock Doors', key: 'dock_doors' },
  { label: 'Power', key: 'power' },
  { label: 'Tenant', key: 'tenant' },
  { label: 'Tenant Rating (S&P)', key: 'tenant_rating' },
  
  // Multi-Family
  { label: '# of Units', key: 'num_units' },
  { label: 'Unit Mix', key: 'unit_mix' },
  { label: 'Price/Unit', key: 'price_unit' },
  { label: 'Net Rentable Area', key: 'nra' },
  { label: 'Gross Bldg Area', key: 'gba' },
  { label: 'Unit Size/SF', key: 'unit_size_sf' },
  { label: 'Beds/Baths', key: 'beds_baths' },
  { label: 'Garages', key: 'garages' },
  { label: 'Heat Source', key: 'heat_source' },
  
  // Hotel
  { label: 'Chain', key: 'chain' },
  { label: 'Scale', key: 'scale' },
  { label: 'Brand/Scale', key: 'brand_scale' },
  { label: 'Room Count', key: 'room_count' },
  { label: 'Price/Room', key: 'price_room' },
  { label: 'RevPAR', key: 'revpar' },
  { label: 'ADR', key: 'adr' },
  
  // Storage
  { label: 'Climate Controlled %', key: 'climate_control' },
  { label: 'Heated', key: 'heated' },
  { label: 'Demised Units', key: 'demised_units' },
];

export const SECTIONS: Section[] = [
  { id: 'transaction', title: 'Transaction Data', color: 'bg-blue-50' },
  { id: 'adjustments', title: 'Transactional Adjustments', color: 'bg-yellow-50' },
  { id: 'quantitative', title: 'Quantitative Adjustments', color: 'bg-purple-50' },
  { id: 'qualitative', title: 'Qualitative Characteristics', color: 'bg-emerald-50' },
  { id: 'valuation', title: 'Valuation Analysis', color: 'bg-white' },
];
